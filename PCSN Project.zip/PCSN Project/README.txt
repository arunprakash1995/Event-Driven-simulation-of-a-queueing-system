CS 6352 - Performance of Computer Systems and Networks
Spring 2017
Name : Arun Prakash Themothy Prabu Vincent (axt161330) 

The Project was developed in Eclipse in MacOS

You run the program with the following command (for a Unix machine):
java -jar “/Location/of/the/pcsn.jar“ Location/of/the/config.txt

The format of the config file is as follows:

{line1}: “Delta - Production rate of Machine 1 in components per minute”
{line2}: “mu - Server Rate(Packaging rate of Workers in components per minute” 
{line3}: “Number of Servers(Number of workers)” 
{line4}: “The value of K(System size)”

Terminal Command to Run : 

java -jar /Users/ArunPrakash/Desktop/pcsn.jar /Users/ArunPrakash/Desktop/config.txt
